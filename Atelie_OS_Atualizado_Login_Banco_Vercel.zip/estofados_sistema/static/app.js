function brl(n){return Number(n||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});}function addItem(){const items=window.ITEMS||[];if(!items.length){alert('Cadastre primeiro os materiais na tabela de preços.');return;}let row=document.createElement('div');row.className='itemrow';let select=document.createElement('select');select.name='item_id';for(let v of items){const o=document.createElement('option');o.value=v.id;o.textContent=v.name+' · '+brl(v.cost)+'/'+v.unit;select.appendChild(o);}let qty=document.createElement('input');qty.type='number';qty.min='0.01';qty.step='0.01';qty.value='1';qty.name='quantity';qty.placeholder='Qtd';let del=document.createElement('button');del.type='button';del.textContent='×';del.onclick=()=>{row.remove();recalc();};select.onchange=recalc;qty.oninput=recalc;row.append(select,qty,del);document.querySelector('#items').append(row);recalc();}function recalc(){if(!document.querySelector('#outcost'))return;let cost=0;let items=window.ITEMS||[];document.querySelectorAll('.itemrow').forEach(r=>{let i=items.find(x=>String(x.id)===r.querySelector('select').value);if(i)cost+=i.cost*Number(r.querySelector('input').value||0);});for(let id of ['labor','freight','other'])cost+=Number(document.getElementById(id)?.value||0);const margin=Math.min(90,Math.max(0,Number(document.getElementById('margin')?.value||0)))/100;let base=cost/(1-margin);document.querySelector('#outcost').textContent=brl(cost);document.querySelector('#outprice').textContent=brl(base);document.querySelector('#outpix').textContent=brl(base*(1-(window.RULES?.pix||0)/100));document.querySelector('#outcard').textContent=brl(base/(1-(window.RULES?.card||0)/100));}document.addEventListener('input',e=>{if(['labor','freight','other','margin'].includes(e.target.id))recalc();});

// Exibe o menu completo somente quando solicitado no celular.
document.addEventListener('DOMContentLoaded',function(){
 const toggle=document.getElementById('mobile-menu-button');
 const nav=document.getElementById('main-nav');
 if(!toggle||!nav)return;
 toggle.addEventListener('click',function(){
   const opened=nav.classList.toggle('mobile-open');
   toggle.setAttribute('aria-expanded',String(opened));
   toggle.textContent=opened?'✕ Fechar':'☰ Menu';
 });
});
